﻿namespace project_gui
{
    partial class booking
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            lblTitle = new Label();
            grpNewBooking = new GroupBox();
            labelCID = new Label();
            labelshnum = new Label();
            txtShowID = new TextBox();
            btnNext = new Button();
            grpManage = new GroupBox();
            btnConfirmStatus = new Button();
            dgvBookings = new DataGridView();
            lblManageID = new Label();
            txtManageID = new TextBox();
            btnCancel = new Button();
            lblNewMethod = new Label();
            cmbNewMethod = new ComboBox();
            btnUpdate = new Button();
            btnStatus = new Button();
            lblStatusResult = new Label();
            lblRevenue = new Label();
            cmbCustomer = new ComboBox();
            grpNewBooking.SuspendLayout();
            grpManage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvBookings).BeginInit();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            lblTitle.Location = new Point(20, 20);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(382, 45);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "Cinema Booking System";
            // 
            // grpNewBooking
            // 
            grpNewBooking.Controls.Add(cmbCustomer);
            grpNewBooking.Controls.Add(labelCID);
            grpNewBooking.Controls.Add(labelshnum);
            grpNewBooking.Controls.Add(txtShowID);
            grpNewBooking.Controls.Add(btnNext);
            grpNewBooking.Location = new Point(20, 80);
            grpNewBooking.Name = "grpNewBooking";
            grpNewBooking.Size = new Size(350, 250);
            grpNewBooking.TabIndex = 1;
            grpNewBooking.TabStop = false;
            grpNewBooking.Text = "1. Create New Booking";
            // 
            // labelCID
            // 
            labelCID.AutoSize = true;
            labelCID.Location = new Point(20, 40);
            labelCID.Name = "labelCID";
            labelCID.Size = new Size(116, 25);
            labelCID.TabIndex = 0;
            labelCID.Text = "Customer ID:";
            // 
            // labelshnum
            // 
            labelshnum.AutoSize = true;
            labelshnum.Location = new Point(20, 90);
            labelshnum.Name = "labelshnum";
            labelshnum.Size = new Size(130, 25);
            labelshnum.TabIndex = 2;
            labelshnum.Text = "Show Number:";
            // 
            // txtShowID
            // 
            txtShowID.Location = new Point(150, 87);
            txtShowID.Name = "txtShowID";
            txtShowID.Size = new Size(180, 31);
            txtShowID.TabIndex = 3;
            // 
            // btnNext
            // 
            btnNext.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnNext.Location = new Point(20, 150);
            btnNext.Name = "btnNext";
            btnNext.Size = new Size(310, 50);
            btnNext.TabIndex = 4;
            btnNext.Text = "Proceed to Payment ➔";
            btnNext.UseVisualStyleBackColor = true;
            btnNext.Click += btnNext_Click;
            // 
            // grpManage
            // 
            grpManage.Controls.Add(btnConfirmStatus);
            grpManage.Controls.Add(dgvBookings);
            grpManage.Controls.Add(lblManageID);
            grpManage.Controls.Add(txtManageID);
            grpManage.Controls.Add(btnCancel);
            grpManage.Controls.Add(lblNewMethod);
            grpManage.Controls.Add(cmbNewMethod);
            grpManage.Controls.Add(btnUpdate);
            grpManage.Controls.Add(btnStatus);
            grpManage.Controls.Add(lblStatusResult);
            grpManage.Location = new Point(390, 80);
            grpManage.Name = "grpManage";
            grpManage.Size = new Size(580, 480);
            grpManage.TabIndex = 2;
            grpManage.TabStop = false;
            grpManage.Text = "2. Manage Bookings";
            // 
            // btnConfirmStatus
            // 
            btnConfirmStatus.Location = new Point(398, 315);
            btnConfirmStatus.Name = "btnConfirmStatus";
            btnConfirmStatus.Size = new Size(162, 35);
            btnConfirmStatus.TabIndex = 9;
            btnConfirmStatus.Text = "confirm status";
            btnConfirmStatus.UseVisualStyleBackColor = true;
            btnConfirmStatus.Click += button1_Click;
            // 
            // dgvBookings
            // 
            dgvBookings.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvBookings.Location = new Point(20, 40);
            dgvBookings.Name = "dgvBookings";
            dgvBookings.ReadOnly = true;
            dgvBookings.RowHeadersWidth = 62;
            dgvBookings.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvBookings.Size = new Size(540, 200);
            dgvBookings.TabIndex = 0;
            // 
            // lblManageID
            // 
            lblManageID.AutoSize = true;
            lblManageID.Location = new Point(20, 260);
            lblManageID.Name = "lblManageID";
            lblManageID.Size = new Size(158, 25);
            lblManageID.TabIndex = 1;
            lblManageID.Text = "Target Booking ID:";
            // 
            // txtManageID
            // 
            txtManageID.Location = new Point(180, 257);
            txtManageID.Name = "txtManageID";
            txtManageID.Size = new Size(100, 31);
            txtManageID.TabIndex = 2;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(300, 254);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(120, 35);
            btnCancel.TabIndex = 3;
            btnCancel.Text = "Cancel Booking";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // lblNewMethod
            // 
            lblNewMethod.AutoSize = true;
            lblNewMethod.Location = new Point(20, 380);
            lblNewMethod.Name = "lblNewMethod";
            lblNewMethod.Size = new Size(119, 25);
            lblNewMethod.TabIndex = 4;
            lblNewMethod.Text = "New Method:";
            // 
            // cmbNewMethod
            // 
            cmbNewMethod.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbNewMethod.FormattingEnabled = true;
            cmbNewMethod.Items.AddRange(new object[] { "Visa", "MasterCard", "Cash", "Fawry", "Vodafone Cash", "InstaPay", "Apple Pay" });
            cmbNewMethod.Location = new Point(180, 380);
            cmbNewMethod.Name = "cmbNewMethod";
            cmbNewMethod.Size = new Size(180, 33);
            cmbNewMethod.TabIndex = 5;
            // 
            // btnUpdate
            // 
            btnUpdate.Location = new Point(380, 378);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(180, 35);
            btnUpdate.TabIndex = 6;
            btnUpdate.Text = "Update ";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnStatus
            // 
            btnStatus.Location = new Point(430, 254);
            btnStatus.Name = "btnStatus";
            btnStatus.Size = new Size(130, 35);
            btnStatus.TabIndex = 7;
            btnStatus.Text = "Check Status";
            btnStatus.UseVisualStyleBackColor = true;
            btnStatus.Click += btnStatus_Click;
            // 
            // lblStatusResult
            // 
            lblStatusResult.AutoSize = true;
            lblStatusResult.Font = new Font("Segoe UI", 9F, FontStyle.Italic);
            lblStatusResult.Location = new Point(138, 320);
            lblStatusResult.Name = "lblStatusResult";
            lblStatusResult.Size = new Size(192, 25);
            lblStatusResult.TabIndex = 8;
            lblStatusResult.Text = "Status will appear here";
            // 
            // lblRevenue
            // 
            lblRevenue.AutoSize = true;
            lblRevenue.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblRevenue.ForeColor = Color.Green;
            lblRevenue.Location = new Point(20, 500);
            lblRevenue.Name = "lblRevenue";
            lblRevenue.Size = new Size(280, 32);
            lblRevenue.TabIndex = 3;
            lblRevenue.Text = "Today's Revenue: $0.00";
            // 
            // cmbCustomer
            // 
            cmbCustomer.FormattingEnabled = true;
            cmbCustomer.Location = new Point(148, 40);
            cmbCustomer.Name = "cmbCustomer";
            cmbCustomer.Size = new Size(182, 33);
            cmbCustomer.TabIndex = 5;
            // 
            // booking
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1000, 600);
            Controls.Add(lblRevenue);
            Controls.Add(grpManage);
            Controls.Add(grpNewBooking);
            Controls.Add(lblTitle);
            Name = "booking";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Cinema Booking Dashboard";
            Load += booking_Load;
            grpNewBooking.ResumeLayout(false);
            grpNewBooking.PerformLayout();
            grpManage.ResumeLayout(false);
            grpManage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvBookings).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.GroupBox grpNewBooking;
        private System.Windows.Forms.Label labelCID;
        private System.Windows.Forms.Label labelshnum;
        private System.Windows.Forms.TextBox txtShowID;
        private System.Windows.Forms.Button btnNext;

        private System.Windows.Forms.GroupBox grpManage;
        private System.Windows.Forms.DataGridView dgvBookings;
        private System.Windows.Forms.Label lblManageID;
        private System.Windows.Forms.TextBox txtManageID;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblNewMethod;
        private System.Windows.Forms.ComboBox cmbNewMethod;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnStatus;
        private System.Windows.Forms.Label lblStatusResult;

        private System.Windows.Forms.Label lblRevenue;
        private Button btnConfirmStatus;
        private ComboBox cmbCustomer;
    }
}