using Microsoft.Data.SqlClient;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace project_gui
{
    public partial class booking : Form
    {

        string connectionString = @"Data Source=localhost\SQLEXPRESS;Initial Catalog=""ciemna-system"";Integrated Security=True;TrustServerCertificate=True;";

        public booking()
        {
            InitializeComponent();
        }

        // Runs automatically when the app starts
       


        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                // Check if the user actually picked an ID from the dropdown
                if (cmbCustomer.SelectedValue == null)
                {
                    MessageBox.Show("Please select a Customer ID from the list.");
                    return;
                }

                // Get the ID from the ComboBox
                int customerId = (int)cmbCustomer.SelectedValue;
                int showId = int.Parse(txtShowID.Text);
                decimal amount = 0;

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand getPriceCmd = new SqlCommand("SELECT Price FROM Show WHERE show_Number = @showId", conn);
                    getPriceCmd.Parameters.AddWithValue("@showId", showId);

                    object result = getPriceCmd.ExecuteScalar();
                    if (result != null)
                    {
                        amount = Convert.ToDecimal(result);
                    }
                    else
                    {
                        MessageBox.Show("Show Number not found!");
                        return;
                    }
                }

                paymentform payForm = new paymentform(customerId, showId, amount);
                if (payForm.ShowDialog() == DialogResult.OK || !payForm.Visible)
                {
                    LoadBookings();
                    LoadDailyRevenue();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }


        // Refreshes the DataGridView to show all bookings
        private void LoadBookings()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Booking", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvBookings.DataSource = dt;
            }
        }

        // Gets the total revenue for today 
        private void LoadDailyRevenue()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT dbo.fn_getDailyRevenue(GETDATE())", conn);
                object result = cmd.ExecuteScalar();
                lblRevenue.Text = "Today's Revenue: $" + (result != DBNull.Value ? result.ToString() : "0.00");
            }
        }
        private void booking_Load(object sender, EventArgs e)
        {
            LoadCustomerList(); // Add this line
            LoadBookings();
            LoadDailyRevenue();
        }
        private void LoadCustomerList()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    // We select both, but we only show the ID to the user
                    string query = "SELECT customer_ID FROM Customer";
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    // Assuming your ComboBox is named comboBox1 or cmbCustomer
                    // If you renamed it in the Designer, change the name below!
                    cmbCustomer.DataSource = dt;
                    cmbCustomer.DisplayMember = "customer_ID"; // Shows the ID number in the list
                    cmbCustomer.ValueMember = "customer_ID";   // Uses the ID number in the code

                    cmbCustomer.SelectedIndex = -1; // Start with no ID selected
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading customer list: " + ex.Message);
                }
            }
        }
       

        // Cancels a booking using
        private void btnCancel_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    //  marks the booking as Cancelled 
                    string sql = "UPDATE Booking SET Booking_Status = 'Cancelled' WHERE Booking_ID = @id";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@id", txtManageID.Text);

                    int rows = cmd.ExecuteNonQuery();

                    if (rows > 0)
                    {
                        MessageBox.Show("Booking Cancelled!");


                        LoadBookings();     // Update the table so 'Cancelled' shows up
                        LoadDailyRevenue(); // Update the revenue label so the money is removed
                    }
                }
                catch (Exception ex) { MessageBox.Show(ex.Message); }
            }
        }
        // Updates the payment method 
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtManageID.Text) || cmbNewMethod.SelectedIndex == -1)
            {
                MessageBox.Show("Please enter a Booking ID and select a New Payment Method.");
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    // update the 'payment' table using a Subquery 

                    string sql = @"UPDATE payment 
                           SET Payment_Method = @method 
                           WHERE payment_id = (SELECT Payment_ID FROM Booking WHERE Booking_ID = @id)";

                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@method", cmbNewMethod.Text);
                    cmd.Parameters.AddWithValue("@id", txtManageID.Text);

                    int rows = cmd.ExecuteNonQuery();

                    if (rows > 0)
                    {
                        MessageBox.Show("Payment method successfully updated!");
                        LoadBookings(); // Refresh the table
                    }
                    else
                    {
                        MessageBox.Show("Could not find a payment record for that Booking ID.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating payment method: " + ex.Message);
                }
            }
        }

        // Checks the combined status 
        private void btnStatus_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("SELECT dbo.get_payment_status(@BookingID)", conn);
                    cmd.Parameters.AddWithValue("@BookingID", int.Parse(txtManageID.Text));

                    string status = (string)cmd.ExecuteScalar();
                    lblStatusResult.Text = "Status: " + status;
                }
                catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtManageID.Text))
            {
                MessageBox.Show("Please enter the Booking ID you want to confirm.");
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    //   flip the status to 'Confirmed'
                    string sql = "UPDATE Booking SET Booking_Status = 'Confirmed' WHERE Booking_ID = @id";

                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@id", txtManageID.Text);

                    int rows = cmd.ExecuteNonQuery();

                    if (rows > 0)
                    {
                        MessageBox.Show("Booking status updated to Confirmed!");

                        //  Refresh UI 
                        LoadBookings();
                        LoadDailyRevenue();
                    }
                    else
                    {
                        MessageBox.Show("Booking ID not found.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating status: " + ex.Message);
                }
            }
        }
    }
}