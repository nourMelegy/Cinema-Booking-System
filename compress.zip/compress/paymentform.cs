﻿using System;
using Microsoft.Data.SqlClient;
using System.Windows.Forms;
using System.Data;
namespace project_gui
{
    public partial class paymentform : Form
    {
        string connectionString = @"Data Source=localhost\SQLEXPRESS;Initial Catalog=""ciemna-system"";Integrated Security=True;TrustServerCertificate=True;";

        // Variables to remember what Form 1 sent us
        private int _customerID;
        private int _showID;
        private decimal _totalAmount;

        // Default constructor for Designer
        public paymentform() { InitializeComponent(); }

        // Custom constructor to receive data from the Booking form
        public paymentform(int customerID, int showID, decimal totalAmount)
        {
            InitializeComponent();
            _customerID = customerID;
            _showID = showID;
            _totalAmount = totalAmount;

            txtAmount.Text = _totalAmount.ToString("0.00"); // Show price on screen
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if (cmbMethod.SelectedIndex == -1 || cmbStatus.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a method and status.");
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    // 1. Insert into Payment Table
                    // We do NOT include payment_id because SQL generates it automatically.
                    // We use SELECT SCOPE_IDENTITY() to get the ID SQL just made.
                    string insertPayment = @"INSERT INTO payment (Payment_Method, Amount, status) 
                                   VALUES (@method, @amount, 'Completed');
                                   SELECT SCOPE_IDENTITY();";

                    SqlCommand cmdPay = new SqlCommand(insertPayment, conn);
                    cmdPay.Parameters.AddWithValue("@method", cmbMethod.Text);
                    cmdPay.Parameters.AddWithValue("@amount", _totalAmount);

                    // Execute and capture the new Payment ID
                    int newPaymentId = Convert.ToInt32(cmdPay.ExecuteScalar());


                    // 2. Insert into Booking Table
                    // We do NOT include Booking_ID because it is also automatic.
                    // We use @payId to link this booking to the payment we just created.
                    string insertBooking = @"INSERT INTO Booking (Booking_Status, Total_Amount, Booking_date, B_shownumber, Customer_ID, Payment_ID) 
                                   VALUES (@bStatus, @amount, GETDATE(), @showId, @custId, @payId);
                                   SELECT SCOPE_IDENTITY();";

                    SqlCommand cmdBook = new SqlCommand(insertBooking, conn);
                    cmdBook.Parameters.AddWithValue("@bStatus", cmbStatus.Text);
                    cmdBook.Parameters.AddWithValue("@amount", _totalAmount);
                    cmdBook.Parameters.AddWithValue("@showId", _showID);
                    cmdBook.Parameters.AddWithValue("@custId", _customerID);
                    cmdBook.Parameters.AddWithValue("@payId", newPaymentId); // This links the two tables!

                    // Execute and capture the new Booking ID
                    int newBookingId = Convert.ToInt32(cmdBook.ExecuteScalar());

                    MessageBox.Show($"Booking Successful!\nYour Booking ID is: {newBookingId}\nPayment ID linked: {newPaymentId}");

                    // Set DialogResult so the main form knows to refresh the table
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                catch (Exception ex)
                {
                    // This will now show the exact column causing trouble if there's a typo
                    MessageBox.Show("Database Error: " + ex.Message);
                }
            }
        }
    }
}